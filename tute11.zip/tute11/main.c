#include <stdio.h>
#include <stdlib.h>

int main()
{
    #include <stdio.h>

int main() {
    int x = 6, y = 4;
    int sum, diff, product;
    float division;

    sum = x + y;
    diff = x - y;
    product = x * y;
    division = (float)x / y;

    printf("Sum: %d\n", sum);
    printf("Difference: %d\n", diff);
    printf("Product: %d\n", product);
    printf("Division: %.2f\n", division);

    return 0;
}



