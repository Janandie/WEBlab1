<?php
for ($count = 5; $count <= 15; $count++) {
    echo $count . "\n";
}
?>
