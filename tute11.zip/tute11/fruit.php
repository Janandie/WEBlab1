<?php
$fruits = array("Apple", "Banana", "Orange", "Grapes", "Mango");
print_r($fruits);
?>
